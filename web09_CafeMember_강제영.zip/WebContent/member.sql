CREATE table member(
	id varchar(20) primary key,
    password varchar(30),
    name varchar(50),
    address varchar(100));

SELECT * from member;