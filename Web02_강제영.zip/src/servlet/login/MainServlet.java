package servlet.login;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Enumeration;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String path;
	public String[] id = new String[5];
	public String[] pass = new String[5];
	public String[] name = new String[5];
	public String[] addr = new String[5];
	int idx = 0;
	int size = 0;
	boolean flag = false;
       
    public MainServlet() {
    }

	public void init() throws ServletException {
		//0. path 초기화
		path = getInitParameter("path");
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}
	
	protected void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		try {
			BufferedReader br = new BufferedReader(new FileReader(path));
			//1-2. path에 있는 데이터 불러오기
			while(br.ready()) {
				String[] strarr = br.readLine().split(" ");
				id[idx] = strarr[0];
				pass[idx] = strarr[1];
				name[idx] = strarr[2];
				addr[idx] = strarr[3];
				idx++;
			}

		}catch(Exception e) {
			System.out.println("자료 읽기 실패");
		}
		
		//2. 입력받은 값 받기

		String getId = request.getParameter("userid");
		String getPass = request.getParameter("password");

		//3. 비교
		for(int i=0;i<id.length;i++) {
			if(id[i].equals(getId)&&pass[i].equals(getPass)) {
				flag=true;
				break;
			}else {
				flag=false;
			}
		}
		if(flag) {
			out.println("<a href = loginSuccess.jsp?id="+getId+">click here</a>");
		}else {
			out.println("<a href = error.jsp?id="+getId+">click here</a>");
		}
	}

}
